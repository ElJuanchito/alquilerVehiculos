package co.edu.uniquindio.alquilervehiculos.exceptions;

public class AlquilerNoExistenteException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AlquilerNoExistenteException(String msg) {
		super(msg);
	}

}
