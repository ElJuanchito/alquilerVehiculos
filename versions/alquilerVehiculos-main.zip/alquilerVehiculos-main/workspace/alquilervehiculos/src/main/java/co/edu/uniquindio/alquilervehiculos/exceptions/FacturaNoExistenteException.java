package co.edu.uniquindio.alquilervehiculos.exceptions;

public class FacturaNoExistenteException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public FacturaNoExistenteException(String msg) {
		super(msg);
	}

}
