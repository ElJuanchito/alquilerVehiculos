package co.edu.uniquindio.alquilervehiculos.exceptions;

public class VehiculoYaAlquiladoException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehiculoYaAlquiladoException(String msg) {
		super(msg);
	}
}
