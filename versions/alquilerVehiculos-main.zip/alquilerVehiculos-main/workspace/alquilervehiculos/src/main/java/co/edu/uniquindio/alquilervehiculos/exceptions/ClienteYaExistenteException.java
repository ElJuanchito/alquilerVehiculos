package co.edu.uniquindio.alquilervehiculos.exceptions;

public class ClienteYaExistenteException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ClienteYaExistenteException(String msg) {
		super(msg);
	}
}
