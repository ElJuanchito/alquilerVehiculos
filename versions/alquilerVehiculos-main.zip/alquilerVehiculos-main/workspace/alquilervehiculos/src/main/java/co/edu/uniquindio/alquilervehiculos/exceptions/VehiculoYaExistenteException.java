package co.edu.uniquindio.alquilervehiculos.exceptions;

public class VehiculoYaExistenteException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehiculoYaExistenteException(String msg) {
		super(msg);
	}
}
