package co.edu.uniquindio.alquilervehiculos.exceptions;

public class VerificarFechasException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public VerificarFechasException(String msg) {
		super(msg);
	}

}
