package co.edu.uniquindio.alquilervehiculos.exceptions;

public class AlquilerYaExistenteException extends Exception{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public AlquilerYaExistenteException(String msg) {
		super(msg);
	}
}
