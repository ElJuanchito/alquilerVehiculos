package co.edu.uniquindio.alquilervehiculos.exceptions;

public class VehiculoNoExistenteException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehiculoNoExistenteException(String msg) {
		super(msg);
	}
}
