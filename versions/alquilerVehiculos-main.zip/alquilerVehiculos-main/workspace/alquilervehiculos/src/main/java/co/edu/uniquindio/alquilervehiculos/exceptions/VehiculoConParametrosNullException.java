package co.edu.uniquindio.alquilervehiculos.exceptions;

public class VehiculoConParametrosNullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehiculoConParametrosNullException(String msg) {
		super(msg);
	}
}
