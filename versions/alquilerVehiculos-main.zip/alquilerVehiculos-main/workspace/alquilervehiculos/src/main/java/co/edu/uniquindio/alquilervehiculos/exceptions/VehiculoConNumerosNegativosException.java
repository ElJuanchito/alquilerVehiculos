package co.edu.uniquindio.alquilervehiculos.exceptions;

public class VehiculoConNumerosNegativosException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public VehiculoConNumerosNegativosException(String msg) {
		super(msg);
	}
}
