package co.edu.uniquindio.alquilervehiculos.exceptions;

public class AlquilerConParametrosNullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AlquilerConParametrosNullException(String msg) {
		super(msg);
	}

}
