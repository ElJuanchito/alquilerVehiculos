package co.edu.uniquindio.alquilervehiculos.exceptions;

public class ClienteConParametrosNullException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ClienteConParametrosNullException(String msg) {
		super(msg);
	}
}
