package co.edu.uniquindio.alquilervehiculos.model;

public class AlquilerTest {

	public AlquilerTest() {
		
	}
	
	/*
	@Test
	public void pruebaConstructor() { 
		Alquiler alquiler = new Alquiler(null, new Vehiculo(null, null, null, null, null, null, 10d, null, null, null), LocalDateTime.now(), LocalDateTime.of(2023, 10, 12, 0, 0));
		alquiler.generarFactura();
		System.out.println(alquiler);
		Alquiler alquiler2 = new Alquiler(null, new Vehiculo(null, null, null, null, null, null, 100d, null, null, null), LocalDateTime.now(), LocalDateTime.of(2023, 10, 12, 0, 0));
		Alquiler.incrementLong();
		alquiler2.setId(Alquiler.getLong());
		alquiler2.generarFactura();
		System.out.println(alquiler2);
	}
	*/
}
